package com.javatpoint.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Books
{
//Defining book id as primary key
@Id
@Column
private int mobile;
@Column
private String name;
@Column
private String pickup;
@Column
private String destination;

public int getMobile() 
{
return mobile;
}
public void setMobile(int mobile) 
{
this.mobile = mobile;
}
public String getName()
{
return name;
}
public void setName(String name) 
{
this.name = name;
}
public String getPickup() 
{
return pickup;
}
public void setPickup(String pickup) 
{
this.pickup = pickup;
}
public String getDestination() 
{
return destination;
}
public void setDestination(String destination) 
{
this.destination = destination;
}

}